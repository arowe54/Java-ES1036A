public class Animal { // Animal is the parent class of the Cat, Dog, and Duck
    public String say(){return "";} // returns an empty string
}
