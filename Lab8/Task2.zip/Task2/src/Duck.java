public class Duck extends Animal{
    @Override
    public String say(){return "quack-quack";}
}
