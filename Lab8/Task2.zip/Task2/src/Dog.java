public class Dog extends Animal {
    @Override
    public String say(){return "arf-arf";}
}
