public class Cat extends Animal { // cat is a subclass of Animal
    @Override
    public String say(){return "meow-meow";} // overrides say() in superclass
}
