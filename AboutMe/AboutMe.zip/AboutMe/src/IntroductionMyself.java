public class IntroductionMyself {
    public static void main(String[] args) {
        final String myName; // this is a constant variable
        final int yearOfBirth;

        // Assignment Variables
        myName = "AK Ouda";
        yearOfBirth = 2004;

        int age = 2022-yearOfBirth;

        System.out.print("My name is "+ myName +", I am "+ age +"years old.");
    }
}
