public class Task1 {
    public static void main(String[] args){
        System.out.print("Welcome to ES1036a course!"); // prints the message to the console
    }
}
