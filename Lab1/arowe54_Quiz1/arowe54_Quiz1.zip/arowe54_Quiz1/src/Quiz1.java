// java program prints the letter z to the console
public class Quiz1 {
    public static void main(String[] args){ // main method
        System.out.println("*****");
        System.out.println(" *   ");
        System.out.println("  *  ");
        System.out.println("    * ");
        System.out.println("******");
    }
}
