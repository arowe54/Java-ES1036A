// prints an interesting message to the Java console over 4 lines
public class Main {
    public static void main(String[] args)
    {
        System.out.println("   *    *    *     *    *    ");
        System.out.println("   *   * *    *   *    * *   ");
        System.out.println("*  *  *****    * *    *****");
        System.out.println(" **  *     *    *    *     *");
    }
}