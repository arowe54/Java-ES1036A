/*
Andrew Rowe
251276493
ES1036A 002
    Task: Add comments to the program to make it readable for the computer
    Tips:
    ctrl + / converts the line with the cursor into a comment
*/
// The restriction: the class should have the name MainProgram

public class MainProgram {

//    The start point of your program
    public static void main(String[] args) {
        System.out.println("It's compiled!"); // It prints "It's compiled!"
    }
}
